<?php
/**
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', 'amiel_db');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8mb4');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'kD8!8<pLS] V9Ran>[,h?u`p^&d<)+|tnCZU|Ii/][o5iAQk+T)zsYK+hN&7f-j#');
define('SECURE_AUTH_KEY', '/ r+3l7]aj^vPj=Op>{OwSOGEr_%ZidE!i4FXM68X5bbRLE[NL*4Un*E@oDI0Zik');
define('LOGGED_IN_KEY', '9}<9U9RExuy&hiTMs|nvEF08HHF^v6aF1/.8 8^:HZFP(H(G{)4sq3uO=Yod!-/X');
define('NONCE_KEY', '{ZdVtu,cp)/3YFZDnxae -5ThqsKyv:g$KKh{d4rZGJRZHS}o.;anpXZ^pS4Ky=h');
define('AUTH_SALT', '!e#Jq./G<:D2gWFJjZhylqdz4BBjM^(%gq0&#C8*6#G(hmwH>OcNm_bt[aqXc#cb');
define('SECURE_AUTH_SALT', 'G43,3;Oho.9^Azn?W`L5`^/^M<NUkQ=xtAcuVBGA},3lC-Q$]~$DrL6Ov+Qm.<@{');
define('LOGGED_IN_SALT', ')*<{Uo{z;m8s,a[m;S5ZoUI2~f;1f|6~3k9E>#UOuMzNKb|Y1Os~Lh=S*a&f.mw+');
define('NONCE_SALT', '%qHn-!S3]v%GR;f%$d<(+v!K*.VXmJUgu{}hG9J~6}O1v06!p[lz3BM_/XZ[P(36');

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'amieldb_';


/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', true);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
